import os
import sys

import pygame

pygame.init()
size1 = width1, height1 = 1350, 690
screen1 = pygame.display.set_mode(size1)
pygame.mixer.music.load('fon.mp3')
pygame.mixer.music.play(-1)
FPS = 30
red_sprites = []
blue_sprites = []
red_to_hide = []
blue_to_hide = []


def load_image1(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image


def load_image(name, colorkey=None):
    fullname = os.path.join(name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    colorkey = image.get_at((0, 0))
    image.set_colorkey(colorkey)
    return image


def terminate():
    pygame.quit()
    sys.exit()


class ScrollBar(object):
    def __init__(self, image_height):
        self.y_axis = 0
        self.image_height = image_height
        self.change_y = 0

        bar_height = int((height1 - 40) / (image_height / (height1 * 1.0)))
        self.bar_rect = pygame.Rect(width1 - 20, 20, 20, bar_height)
        self.bar_up = pygame.Rect(width1 - 20, 0, 20, 20)
        self.bar_down = pygame.Rect(width1 - 20, height1 - 20, 20, 20)

        self.bar_up_image = load_image1("up.png")
        self.bar_down_image = load_image1("down.png")

        self.on_bar = False
        self.mouse_diff = 0

    def update(self):
        self.y_axis += self.change_y

        if self.y_axis > 0:
            self.y_axis = 0
        elif (self.y_axis + self.image_height) < height1:
            self.y_axis = height1 - self.image_height

        height_diff = self.image_height - height1

        scroll_length = height1 - self.bar_rect.height - 40
        bar_half_lenght = self.bar_rect.height / 2 + 20

        if self.on_bar:
            pos = pygame.mouse.get_pos()
            self.bar_rect.y = pos[1] - self.mouse_diff
            if self.bar_rect.top < 20:
                self.bar_rect.top = 20
            elif self.bar_rect.bottom > (height1 - 20):
                self.bar_rect.bottom = height1 - 20

            self.y_axis = int(height_diff / (scroll_length * 1.0) * (self.bar_rect.centery - bar_half_lenght) * -1)
        else:
            self.bar_rect.centery = scroll_length / (height_diff * 1.0) * (self.y_axis * -1) + bar_half_lenght

    def event_handler(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            if self.bar_rect.collidepoint(pos):
                self.mouse_diff = pos[1] - self.bar_rect.y
                self.on_bar = True
            elif self.bar_up.collidepoint(pos):
                self.change_y = 5
            elif self.bar_down.collidepoint(pos):
                self.change_y = -5

        if event.type == pygame.MOUSEBUTTONUP:
            self.change_y = 0
            self.on_bar = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.change_y = 5
            elif event.key == pygame.K_DOWN:
                self.change_y = -5

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_UP:
                self.change_y = 0
            elif event.key == pygame.K_DOWN:
                self.change_y = 0

    def draw(self, screen):
        pygame.draw.rect(screen, (197, 194, 197), self.bar_rect)

        screen.blit(self.bar_up_image, (width1 - 20, 0))
        screen.blit(self.bar_down_image, (width1 - 20, height1 - 20))


def rule_screen():
    screen1.fill((0, 0, 0))
    intro_image = pygame.Surface((1120, 970))
    with open('data/RULLS.txt', 'rt', encoding='utf-8') as f:
        intro_text = f.read().split('\n')
    font = pygame.font.Font(None, 25)
    font2 = pygame.font.Font(None, 30)
    text_coord = 10
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('red'))
        intro_image.blit(string_rendered, (10, text_coord))
        text_coord += 25
    back_btn = pygame.transform.scale(load_image1('buttons.jpg'), (200, 75))
    scrollbar = ScrollBar(970)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and 1120 <= event.pos[0] <= 1320 and 10 <= event.pos[1] <= 85:
                start_screen()
            scrollbar.event_handler(event)
        scrollbar.update()
        screen1.fill('black')
        screen1.blit(back_btn, (1120, 10))
        screen1.blit(font2.render('Назад', 1, pygame.Color('red')), (1190, 38))
        screen1.blit(intro_image, (0, scrollbar.y_axis))
        scrollbar.draw(screen1)
        pygame.display.flip()
        clock.tick(FPS)


def start_screen():
    clock1 = pygame.time.Clock()
    intro_text = ["                                               ФАНТАСТИЧЕСКИЕ БИТВЫ",
                  "", ""]
    intro_text2 = ["", "                                                                                         \
               ИГРАТЬ",
                   "", "", "",
                   "                                                                                         \
             ПРАВИЛА",
                   "", "", "",
                   "                                                                          \
                    О РАЗРАБОТЧИКАХ"]

    fon = pygame.transform.scale(load_image1('start_window_fon.jpg'), (width1, height1))
    screen1.blit(fon, (0, 0))
    btn1 = pygame.transform.scale(load_image1('buttons.jpg'), (240, 100))
    btn2 = pygame.transform.scale(load_image1('buttons.jpg'), (240, 100))
    btn3 = pygame.transform.scale(load_image1('buttons.jpg'), (240, 100))
    screen1.blit(btn1, (550, 230))
    screen1.blit(btn2, (550, 350))
    screen1.blit(btn3, (550, 470))
    font1 = pygame.font.Font(None, 50)
    font2 = pygame.font.Font(None, 30)
    text_coord = 100
    pygame.display.set_caption('Фантастические битвы')
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('yellow'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    for line in intro_text2:
        string_rendered = font2.render(line, 1, pygame.Color('yellow'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 550 <= event.pos[0] <= 790 and 470 <= event.pos[1] <= 570:
                    about_us()
                elif 550 <= event.pos[0] <= 790 and 230 <= event.pos[1] <= 330:
                    story1()
                elif 550 <= event.pos[0] <= 790 and 350 <= event.pos[1] <= 450:
                    rule_screen()
        pygame.display.flip()
        clock1.tick(50)


def about_us():
    clock2 = pygame.time.Clock()
    screen1.fill((0, 0, 0))
    btn1 = pygame.transform.scale(load_image1('buttons.jpg'), (120, 50))
    screen1.blit(btn1, (550, 570))
    intro_text = ["                                                                                    \
    О РАЗРАБОТЧИКАХ", "", "", "Разработчики: Корнилов Анатолий, Спиридонов Даниил, Бурмистрова Екатерина",
                  "Идея: Корнилов Анатолий", "Персонажи: Корнилов Анатолий", "Графика: Бурмистрова Екатерина",
                  "Звук: Корнилов Анатолий", "Реализация стартового окна: Корнилов Анатолий",
                  'Реализация окна "Правила": Бурмистрова Екатерина',
                  'Реализация окна "О разработчиках": Корнилов Анатолий',
                  "Реализация окна выбора персонажей: Корнилов Анатолий",
                  "Реализация боя: Спиридонов Даниил", "Реализация персонажей: Спиридонов Даниил",
                  "Реализация экрана окончания и подсчёта очков: Корнилов Анатолий", "Анимация: Бурмистрова Екатерина",
                  "Описание героев и предыстория: Корнилов Анатолий", "",
                  "Все права защищены."]
    intro_text2 = ["                                                                                       \
                            Назад"]
    font1 = pygame.font.Font(None, 25)
    text_coord = 50
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    for line in intro_text2:
        string_rendered = font1.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 550 <= event.pos[0] <= 670 and 570 <= event.pos[1] <= 620:
                    screen1.fill((0, 0, 0))
                    start_screen()
        pygame.display.flip()
        clock2.tick(50)


def story1():
    clock3 = pygame.time.Clock()
    screen1.fill((0, 0, 0))
    fon = pygame.transform.scale(load_image1('story.jpg'), (width1, height1))
    screen1.blit(fon, (0, 0))
    intro_text = ["                                                  \
                   Когда-то Земля была прекрасным миром.",
                  "                                                        \
                        Но войны всё поглотили.",
                  "                                    \
              Люди убивали друг друга из-за так называемых политических проблем...",
                  "                                    \
              Многие уже стали жить в страхе смерти и готовы убивать кого-угодно... "]
    font1 = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                story2()
        pygame.display.flip()
        clock3.tick(50)


def story2():
    clock4 = pygame.time.Clock()
    screen1.fill((0, 0, 0))
    fon = pygame.transform.scale(load_image1('story.jpg'), (width1, height1))
    screen1.blit(fon, (0, 0))
    intro_text = ["                                                  \
                И на Землю прилетели для завоевания разные инопланетяне...",
                  "                                                        \
                    Теперь человечеству грозит уничтожение.",
                  "                                    \
                         Но люди не едины и постоянно враждуют между собой...",
                  "                                    \
                  И некоторые стали ничуть не слабее более продвинутых захватчиков... "]
    font1 = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                story3()
        pygame.display.flip()
        clock4.tick(50)


def story3():
    clock5 = pygame.time.Clock()
    screen1.fill((0, 0, 0))
    fon = pygame.transform.scale(load_image1('story.jpg'), (width1, height1))
    screen1.blit(fon, (0, 0))
    intro_text = ["                            Большинство из сильных землян уверены, что всё достигается только силой\
 и стали кровавыми убийцами/",
                  "                                                        \
    Лишь где-то сидит в своём логове благородный Учёный,",
                  "                                    \
                  Который создал Робота-миротворца и сыворотку сверхчеловека,",
                  "                                    \
                      Из-за которой сам стал неконтролируемым монстром..."]
    font1 = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                story4()
        pygame.display.flip()
        clock5.tick(50)


def story4():
    clock6 = pygame.time.Clock()
    screen1.fill((0, 0, 0))
    fon = pygame.transform.scale(load_image1('story.jpg'), (width1, height1))
    screen1.blit(fon, (0, 0))
    intro_text = ["                            И поэтому некоторые из них иногда объединяются в небольшие коалиции \
и временно становятся союзниками",
                  "                                                        \
    И пытаются убить всех врагов - ибо это цель их жизни.",
                  "                                    \
                                     Объедините героев, чтобы победить!!!"]
    font1 = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                choose_heroes()
        pygame.display.flip()
        clock6.tick(50)


def choose_heroes():
    clock6 = pygame.time.Clock()
    screen1.fill(pygame.Color('gray'))
    acid_monstr = pygame.transform.scale(load_image1('acid-monstr_icon.png'), (100, 100))
    screen1.blit(acid_monstr, (50, 200))
    robot = pygame.transform.scale(load_image1('robot_icon.png'), (100, 100))
    screen1.blit(robot, (165, 200))
    golem = pygame.transform.scale(load_image1('golem_icon.png'), (100, 100))
    screen1.blit(golem, (280, 200))
    witch = pygame.transform.scale(load_image1('magician_icon.png'), (100, 100))
    screen1.blit(witch, (395, 200))
    alien = pygame.transform.scale(load_image1('alien_icon.png'), (100, 100))
    screen1.blit(alien, (510, 200))
    robo_cloud = pygame.transform.scale(load_image1('robo-cloud_icon.png'), (100, 100))
    screen1.blit(robo_cloud, (625, 200))
    ninja = pygame.transform.scale(load_image1('ninja_icon.png'), (100, 100))
    screen1.blit(ninja, (740, 200))
    one_hand_killer = pygame.transform.scale(load_image1('one-hand-killer_icon.png'), (100, 100))
    screen1.blit(one_hand_killer, (855, 200))
    superghost = pygame.transform.scale(load_image1('superghost_icon.png'), (100, 100))
    screen1.blit(superghost, (970, 200))
    maniak = pygame.transform.scale(load_image1('maniak_icon.png'), (100, 100))
    screen1.blit(maniak, (1085, 200))
    sea_monstr = pygame.transform.scale(load_image1('sea-monstr_icon.png'), (100, 100))
    screen1.blit(sea_monstr, (1200, 200))
    pygame.draw.line(screen1, (0, 0, 0), (0, 194), (1350, 194), 5)
    pygame.draw.line(screen1, (0, 0, 0), (0, 306), (1350, 306), 5)
    pygame.draw.line(screen1, (0, 0, 0), (675, 306), (675, 690), 5)
    not_chosen_hero = pygame.transform.scale(load_image1('not_chosen_hero.jpg'), (100, 100))
    screen1.blit(not_chosen_hero, (175, 400))
    screen1.blit(not_chosen_hero, (325, 400))
    screen1.blit(not_chosen_hero, (175, 550))
    screen1.blit(not_chosen_hero, (325, 550))
    screen1.blit(not_chosen_hero, (825, 400))
    screen1.blit(not_chosen_hero, (975, 400))
    screen1.blit(not_chosen_hero, (825, 550))
    screen1.blit(not_chosen_hero, (975, 550))
    text = ["                                      Первый игрок                                                  \
                                Второй игрок"]

    font1 = pygame.font.Font(None, 30)
    text_coord = 350
    for line in text:
        string_rendered = font1.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    first = []
    second = []
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    pygame.draw.rect(screen1, pygame.Color('gray'), pygame.Rect(0, 0, 1350, 190), 0)
                    if 50 <= event.pos[0] <= 150 and 200 <= event.pos[1] <= 300 and 'acid-monstr' not in first and \
                            'acid-monstr' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(acid_monstr, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(acid_monstr, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(acid_monstr, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(acid_monstr, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(50, 200, 100, 100), 0)
                            first.append('acid-monstr')
                        else:
                            if len(second) == 0:
                                screen1.blit(acid_monstr, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(acid_monstr, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(acid_monstr, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(acid_monstr, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(50, 200, 100, 100), 0)
                            second.append('acid-monstr')
                    elif 165 <= event.pos[0] <= 265 and 200 <= event.pos[1] <= 300 and 'robot' not in first and \
                            'robot' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(robot, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(robot, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(robot, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(robot, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(165, 200, 100, 100), 0)
                            first.append('robot')
                        else:
                            if len(second) == 0:
                                screen1.blit(robot, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(robot, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(robot, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(robot, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(165, 200, 100, 100), 0)
                            second.append('robot')
                    elif 280 <= event.pos[0] <= 380 and 200 <= event.pos[1] <= 300 and 'golem' not in first and \
                            'golem' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(golem, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(golem, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(golem, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(golem, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(280, 200, 100, 100), 0)
                            first.append('golem')
                        else:
                            if len(second) == 0:
                                screen1.blit(golem, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(golem, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(golem, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(golem, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(280, 200, 100, 100), 0)
                            second.append('golem')
                    elif 395 <= event.pos[0] <= 495 and 200 <= event.pos[1] <= 300 and 'witch' not in first and \
                            'witch' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(witch, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(witch, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(witch, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(witch, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(395, 200, 100, 100), 0)
                            first.append('witch')
                        else:
                            if len(second) == 0:
                                screen1.blit(witch, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(witch, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(witch, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(witch, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(395, 200, 100, 100), 0)
                            second.append('witch')
                    elif 510 <= event.pos[0] <= 610 and 200 <= event.pos[1] <= 300 and 'alien' not in first and \
                            'alien' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(alien, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(alien, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(alien, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(alien, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(510, 200, 100, 100), 0)
                            first.append('alien')
                        else:
                            if len(second) == 0:
                                screen1.blit(alien, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(alien, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(alien, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(alien, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(510, 200, 100, 100), 0)
                            second.append('alien')
                    elif 625 <= event.pos[0] <= 725 and 200 <= event.pos[1] <= 300 and 'robo-cloud' not in first and \
                            'robo-cloud' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(robo_cloud, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(robo_cloud, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(robo_cloud, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(robo_cloud, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(625, 200, 100, 100), 0)
                            first.append('robo-cloud')
                        else:
                            if len(second) == 0:
                                screen1.blit(robo_cloud, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(robo_cloud, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(robo_cloud, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(robo_cloud, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(625, 200, 100, 100), 0)
                            second.append('robo-cloud')
                    elif 740 <= event.pos[0] <= 840 and 200 <= event.pos[1] <= 300 and 'ninja' not in first and \
                            'ninja' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(ninja, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(ninja, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(ninja, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(ninja, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(740, 200, 100, 100), 0)
                            first.append('ninja')
                        else:
                            if len(second) == 0:
                                screen1.blit(ninja, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(ninja, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(ninja, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(ninja, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(740, 200, 100, 100), 0)
                            second.append('ninja')
                    elif 855 <= event.pos[0] <= 955 and 200 <= event.pos[1] <= 300 and \
                            'one-hand-killer' not in first and 'one-hand-killer' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(one_hand_killer, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(one_hand_killer, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(one_hand_killer, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(one_hand_killer, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(855, 200, 100, 100), 0)
                            first.append('one-hand-killer')
                        else:
                            if len(second) == 0:
                                screen1.blit(one_hand_killer, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(one_hand_killer, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(one_hand_killer, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(one_hand_killer, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(855, 200, 100, 100), 0)
                            second.append('one-hand-killer')
                    elif 970 <= event.pos[0] <= 1050 and 200 <= event.pos[1] <= 300 and 'superghost' not in first and \
                            'superghost' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(superghost, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(superghost, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(superghost, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(superghost, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(970, 200, 100, 100), 0)
                            first.append('superghost')
                        else:
                            if len(second) == 0:
                                screen1.blit(superghost, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(superghost, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(superghost, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(superghost, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(970, 200, 100, 100), 0)
                            second.append('superghost')
                    elif 1085 <= event.pos[0] <= 1185 and 200 <= event.pos[1] <= 300 and 'maniak' not in first and \
                            'maniak' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(maniak, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(maniak, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(maniak, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(maniak, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(1085, 200, 100, 100), 0)
                            first.append('maniak')
                        else:
                            if len(second) == 0:
                                screen1.blit(maniak, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(maniak, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(maniak, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(maniak, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(1085, 200, 100, 100), 0)
                            second.append('maniak')
                    elif 1200 <= event.pos[0] <= 1300 and 200 <= event.pos[1] <= 300 and 'sea-monstr' not in first and \
                            'sea-monstr' not in second:
                        if len(first) == len(second):
                            if len(first) == 0:
                                screen1.blit(sea_monstr, (175, 400))
                            elif len(first) == 1:
                                screen1.blit(sea_monstr, (325, 400))
                            elif len(first) == 2:
                                screen1.blit(sea_monstr, (175, 550))
                            elif len(first) == 3:
                                screen1.blit(sea_monstr, (325, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(1200, 200, 100, 100), 0)
                            first.append('sea-monstr')
                        else:
                            if len(second) == 0:
                                screen1.blit(sea_monstr, (825, 400))
                            elif len(second) == 1:
                                screen1.blit(sea_monstr, (975, 400))
                            elif len(second) == 2:
                                screen1.blit(sea_monstr, (825, 550))
                            elif len(second) == 3:
                                screen1.blit(sea_monstr, (975, 550))
                            pygame.draw.rect(screen1, (0, 0, 0), pygame.Rect(1200, 200, 100, 100), 0)
                            second.append('sea-monstr')
                elif event.button == 3:
                    pygame.draw.rect(screen1, pygame.Color('gray'), pygame.Rect(0, 0, 1350, 190), 0)
                    if 50 <= event.pos[0] <= 150 and 200 <= event.pos[1] <= 300:
                        with open('acid-monstr.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 165 <= event.pos[0] <= 265 and 200 <= event.pos[1] <= 300:
                        with open('robot.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 280 <= event.pos[0] <= 380 and 200 <= event.pos[1] <= 300:
                        with open('golem.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 395 <= event.pos[0] <= 495 and 200 <= event.pos[1] <= 300:
                        with open('witch.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 510 <= event.pos[0] <= 610 and 200 <= event.pos[1] <= 300:
                        with open('alien.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 625 <= event.pos[0] <= 725 and 200 <= event.pos[1] <= 300:
                        with open('robo-cloud.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 740 <= event.pos[0] <= 840 and 200 <= event.pos[1] <= 300:
                        with open('ninja.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 855 <= event.pos[0] <= 955 and 200 <= event.pos[1] <= 300:
                        with open('one-hand-killer.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 970 <= event.pos[0] <= 1070 and 200 <= event.pos[1] <= 300:
                        with open('superghost.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 1085 <= event.pos[0] <= 1185 and 200 <= event.pos[1] <= 300:
                        with open('maniak.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
                    elif 1200 <= event.pos[0] <= 1300 and 200 <= event.pos[1] <= 300:
                        with open('sea-monstr.txt', 'rt', encoding='utf-8') as f:
                            sp = f.read().split('\n')
                            font1 = pygame.font.Font(None, 15)
                            text_coord = 5
                            for line in sp:
                                string_rendered = font1.render(line, 1, pygame.Color('black'))
                                intro_rect = string_rendered.get_rect()
                                text_coord += 10
                                intro_rect.top = text_coord
                                intro_rect.x = 10
                                text_coord += intro_rect.height
                                screen1.blit(string_rendered, intro_rect)
        if len(second) > 4:
            second = second[4:]
            first = first[4:]
        if len(second) == 4:
            before_fighting(first, second)
        pygame.display.flip()
        clock6.tick(50)


def before_fighting(f, s):
    clock7 = pygame.time.Clock()
    screen1.fill((0, 0, 0))
    fon = pygame.transform.scale(load_image1('start_window_fon.jpg'), (1350, 690))
    screen1.blit(fon, (0, 0))
    intro_text = ["                                 Ваши составы собраны и готовы к бою.", "", "", "", "", "",
                  "                                                     ВЫ ГОТОВЫ К БОЮ?"]
    font1 = pygame.font.Font(None, 50)
    text_coord = 50
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('yellow'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                battle(f, s)
        pygame.display.flip()
        clock7.tick(50)


def finish(winner, points):
    clock8 = pygame.time.Clock()
    screen1.fill((0, 0, 0))
    fon = pygame.transform.scale(load_image1('finish.jpeg'), (1350, 690))
    screen1.blit(fon, (0, 0))
    btn1 = pygame.transform.scale(load_image1('buttons.jpg'), (240, 100))
    screen1.blit(btn1, (335, 450))
    screen1.blit(btn1, (815, 450))
    string = '                                      Победил ' + winner + ' игрок и получает ' + str(points)
    if points == 1:
        string += ' очко'
    else:
        string += ' очка'
    intro_text = [string]
    intro_text2 = ['                                                             В главное меню                        \
                               Играть снова']
    font1 = pygame.font.Font(None, 50)
    font2 = pygame.font.Font(None, 30)
    text_coord1 = 100
    text_coord2 = 480
    for line in intro_text:
        string_rendered = font1.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord1 += 10
        intro_rect.top = text_coord1
        intro_rect.x = 10
        text_coord1 += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    for line in intro_text2:
        string_rendered = font2.render(line, 1, pygame.Color('red'))
        intro_rect = string_rendered.get_rect()
        text_coord2 += 10
        intro_rect.top = text_coord2
        intro_rect.x = 10
        text_coord2 += intro_rect.height
        screen1.blit(string_rendered, intro_rect)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 335 <= event.pos[0] <= 575 and 450 <= event.pos[1]:
                    start_screen()
                elif 815 <= event.pos[0] <= 1055 and 450 <= event.pos[1] <= 550:
                    choose_heroes()
        pygame.display.flip()
        clock8.tick(50)


class Board:
    # создание поля
    def __init__(self):
        self.left = 150
        self.top = 10
        self.cell_size = 150
        self.red_units = []
        self.blue_units = []
        self.red_can_beat = [0, 1, 2, 3]
        self.blue_can_beat = [0, 1, 2, 3]
        self.red_golem = False
        self.blue_golem = False
        self.round = 0
        self.my_unit = False
        self.enemy_unit = False

    def sprites(self, screen):
        global all_sprites, red_sprites, blue_sprites
        for i in range(4):
            if self.red_units[i].cur_hp[0] > 0:
                sprite = AnimatedSprite(self.red_units[i].img[:-4], *self.red_units[i].attack_xy,
                                        *self.red_units[i].idle_xy, 160, 20 + i * self.cell_size,
                                        status='attack')
                red_sprites.append(sprite)
            if self.blue_units[i].cur_hp[0] > 0:
                sprite = AnimatedSprite(self.blue_units[i].img[:-4], *self.blue_units[i].attack_xy,
                                        *self.blue_units[i].idle_xy, 1060, 20 + i * self.cell_size,
                                        status='attack')
                blue_sprites.append(sprite)

    def print_info(self, screen):
        intro_text = ["", "", f"         hp: {max(0, self.red_units[0].cur_hp[0])}",
                      "",
                      f"damage: {self.red_units[0].cur_damage[0]}",
                      "", "", "", "", "",
                      f"         hp: {max(0, self.red_units[1].cur_hp[0])}",
                      "",
                      f"damage: {self.red_units[1].cur_damage[0]}",
                      "", "", "", "", "",
                      f"         hp: {max(0, self.red_units[2].cur_hp[0])}",
                      "",
                      f"damage: {self.red_units[2].cur_damage[0]}",
                      "", "", "", "", "",
                      f"         hp: {max(0, self.red_units[3].cur_hp[0])}",
                      "",
                      f"damage: {self.red_units[3].cur_damage[0]}"
                      ]
        font1 = pygame.font.Font(None, 25)
        text_coord = 4
        for line in intro_text:
            string_rendered = font1.render(line, True, pygame.Color('white'))
            intro_rect = string_rendered.get_rect()
            text_coord += 2
            intro_rect.top = text_coord
            intro_rect.x = 25
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)
        intro_text = ["", "", f"         hp: {max(0, self.blue_units[0].cur_hp[0])}",
                      "",
                      f"damage: {self.blue_units[0].cur_damage[0]}",
                      "", "", "", "", "",
                      f"         hp: {max(0, self.blue_units[1].cur_hp[0])}",
                      "",
                      f"damage: {self.blue_units[1].cur_damage[0]}",
                      "", "", "", "", "",
                      f"         hp: {max(0, self.blue_units[2].cur_hp[0])}",
                      "",
                      f"damage: {self.blue_units[2].cur_damage[0]}",
                      "", "", "", "", "",
                      f"         hp: {max(0, self.blue_units[3].cur_hp[0])}",
                      "",
                      f"damage: {self.blue_units[3].cur_damage[0]}"
                      ]
        font1 = pygame.font.Font(None, 25)
        text_coord = 4
        for line in intro_text:
            string_rendered = font1.render(line, True, pygame.Color('white'))
            intro_rect = string_rendered.get_rect()
            text_coord += 2
            intro_rect.top = text_coord
            intro_rect.x = 1220
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)

    def render(self, screen):
        for i in range(4):
            rect = pygame.Rect(150, 10 + i * self.cell_size,
                               self.cell_size, self.cell_size)
            pygame.draw.rect(screen, pygame.Color('white'), rect, 1)

            rect = pygame.Rect(1050, 10 + i * self.cell_size,
                               self.cell_size, self.cell_size)
            pygame.draw.rect(screen, pygame.Color('white'), rect, 1)

        if self.my_unit and self.round == 0:
            rect = pygame.Rect(150, 10 + (self.my_unit - 1) * self.cell_size,
                               self.cell_size, self.cell_size)
            pygame.draw.rect(screen, pygame.Color('yellow'), rect, 0)
        elif self.my_unit:
            rect = pygame.Rect(1050, 10 + (self.my_unit - 1) * self.cell_size,
                               self.cell_size, self.cell_size)
            pygame.draw.rect(screen, pygame.Color('yellow'), rect, 0)

        if self.enemy_unit and self.round == 0:
            rect = pygame.Rect(1050, 10 + (self.enemy_unit - 1) * self.cell_size,
                               self.cell_size, self.cell_size)
            pygame.draw.rect(screen, pygame.Color('orange'), rect, 0)
        elif self.enemy_unit:
            rect = pygame.Rect(150, 10 + (self.enemy_unit - 1) * self.cell_size,
                               self.cell_size, self.cell_size)
            pygame.draw.rect(screen, pygame.Color('orange'), rect, 0)

    def no_info_about_dead(self, screen):
        global red_sprites, blue_sprites
        for i in range(4):
            if board.red_units[i].cur_hp[0] <= 0 and red_sprites[i].status != 'death':
                rect = pygame.Rect(0, 10 + i * self.cell_size,
                                   self.cell_size * 2 + 50, self.cell_size)
                pygame.draw.rect(screen, pygame.Color('grey'), rect, 0)

            if board.blue_units[i].cur_hp[0] <= 0 and blue_sprites[i].status != 'death':
                rect = pygame.Rect(1050, 10 + i * self.cell_size,
                                   self.cell_size * 2, self.cell_size)
                pygame.draw.rect(screen, pygame.Color('grey'), rect, 0)

    def attack(self):
        global red_sprites, blue_sprites
        if self.enemy_unit:
            if self.round == 0 and self.blue_golem and self.blue_units[self.blue_golem - 1].cur_hp[0] > 0:
                if self.red_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.red_units[self.my_unit - 1].cur_damage[0] = self.red_units[self.my_unit - 1].damage
                else:
                    self.red_units[self.my_unit - 1].cur_damage[1] -= 1
                self.blue_units[self.blue_golem - 1].cur_hp[0] -= self.red_units[self.my_unit - 1].cur_damage[0]
                if self.red_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.red_units[self.my_unit - 1].cur_damage[0] = self.red_units[self.my_unit - 1].damage

                if self.blue_units[self.blue_golem - 1].cur_hp[0] > 0 and self.blue_units[
                    self.blue_golem - 1].counterattack > 0:
                    self.red_units[self.my_unit - 1].cur_hp[0] -= 1

                if self.blue_units[self.blue_golem - 1].cur_hp[0] >= 0 and self.blue_units[
                    self.blue_golem - 1].armor > 0:
                    self.blue_units[self.blue_golem - 1].cur_hp[0] += 1

                if board.blue_units[self.blue_golem - 1].cur_hp[0] > 0:
                    blue_sprites[self.blue_golem - 1].change_status('hurt',
                                                                    *self.blue_units[self.blue_golem - 1].hurt_xy)
                else:
                    blue_sprites[self.blue_golem - 1].change_status('death',
                                                                    *self.blue_units[self.blue_golem - 1].death_xy)
                red_sprites[self.my_unit - 1].change_status('attack', *self.red_units[self.my_unit - 1].attack_xy)

            elif self.round == 0:
                if self.red_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.red_units[self.my_unit - 1].cur_damage[0] = self.red_units[self.my_unit - 1].damage
                else:
                    self.red_units[self.my_unit - 1].cur_damage[1] -= 1
                self.blue_units[self.enemy_unit - 1].cur_hp[0] -= self.red_units[self.my_unit - 1].cur_damage[0]
                if self.red_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.red_units[self.my_unit - 1].cur_damage[0] = self.red_units[self.my_unit - 1].damage

                if self.blue_units[self.enemy_unit - 1].cur_hp[0] > 0 and self.blue_units[
                    self.enemy_unit - 1].counterattack > 0:
                    self.red_units[self.my_unit - 1].cur_hp[0] -= 1

                if self.blue_units[self.enemy_unit - 1].cur_hp[0] >= 0 and self.blue_units[
                    self.enemy_unit - 1].armor > 0:
                    self.blue_units[self.enemy_unit - 1].cur_hp[0] += 1

                if board.blue_units[self.enemy_unit - 1].cur_hp[0] > 0:
                    blue_sprites[self.enemy_unit - 1].change_status('hurt',
                                                                    *self.blue_units[self.enemy_unit - 1].hurt_xy)
                else:
                    blue_sprites[self.enemy_unit - 1].change_status('death',
                                                                    *self.blue_units[self.enemy_unit - 1].death_xy)
                red_sprites[self.my_unit - 1].change_status('attack', *self.red_units[self.my_unit - 1].attack_xy)

            elif self.red_golem and self.red_units[self.red_golem - 1].cur_hp[0] > 0:
                if self.blue_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.blue_units[self.my_unit - 1].cur_damage[0] = self.blue_units[self.my_unit - 1].damage
                else:
                    self.blue_units[self.my_unit - 1].cur_damage[1] -= 1
                self.red_units[self.red_golem - 1].cur_hp[0] -= self.blue_units[self.my_unit - 1].cur_damage[0]
                if self.blue_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.blue_units[self.my_unit - 1].cur_damage[0] = self.blue_units[self.my_unit - 1].damage

                if self.red_units[self.red_golem - 1].cur_hp[0] > 0 and self.red_units[
                    self.red_golem - 1].counterattack > 0:
                    self.blue_units[self.my_unit - 1].cur_hp[0] -= 1

                if self.red_units[self.red_golem - 1].cur_hp[0] >= 0 and self.red_units[self.red_golem - 1].armor > 0:
                    self.red_units[self.red_golem - 1].cur_hp[0] += 1

                if board.red_units[self.red_golem - 1].cur_hp[0] > 0:
                    red_sprites[self.red_golem - 1].change_status('hurt',
                                                                  *self.red_units[self.red_golem - 1].hurt_xy)
                else:
                    red_sprites[self.red_golem - 1].change_status('death',
                                                                  *self.red_units[self.red_golem - 1].death_xy)
                blue_sprites[self.my_unit - 1].change_status('attack', *self.blue_units[self.my_unit - 1].attack_xy)

            else:
                if self.blue_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.blue_units[self.my_unit - 1].cur_damage[0] = self.blue_units[self.my_unit - 1].damage
                else:
                    self.blue_units[self.my_unit - 1].cur_damage[1] -= 1
                self.red_units[self.enemy_unit - 1].cur_hp[0] -= self.blue_units[self.my_unit - 1].cur_damage[0]
                if self.blue_units[self.my_unit - 1].cur_damage[1] == 0:
                    self.blue_units[self.my_unit - 1].cur_damage[0] = self.blue_units[self.my_unit - 1].damage

                if self.red_units[self.enemy_unit - 1].cur_hp[0] > 0 and self.red_units[
                    self.enemy_unit - 1].counterattack > 0:
                    self.blue_units[self.my_unit - 1].cur_hp[0] -= 1

                if self.red_units[self.enemy_unit - 1].cur_hp[0] >= 0 and self.red_units[self.enemy_unit - 1].armor > 0:
                    self.red_units[self.enemy_unit - 1].cur_hp[0] += 1

                if board.red_units[self.enemy_unit - 1].cur_hp[0] > 0:
                    red_sprites[self.enemy_unit - 1].change_status('hurt',
                                                                   *self.red_units[self.enemy_unit - 1].hurt_xy)
                else:
                    red_sprites[self.enemy_unit - 1].change_status('death',
                                                                   *self.red_units[self.enemy_unit - 1].death_xy)
                blue_sprites[self.my_unit - 1].change_status('attack', *self.blue_units[self.my_unit - 1].attack_xy)
            if self.round == 0 and self.my_unit == self.red_golem:
                self.red_golem = False
            if self.round == 1 and self.blue_golem == self.my_unit:
                self.blue_golem = False
            if self.round == 0 and self.red_units[self.my_unit - 1].counterattack > 0:
                self.red_units[self.my_unit - 1].counterattack -= 1
            if self.round == 1 and self.blue_units[self.my_unit - 1].counterattack > 0:
                self.blue_units[self.my_unit - 1].counterattack -= 1
            if self.round == 0 and self.red_units[self.my_unit - 1].armor > 0:
                self.red_units[self.my_unit - 1].armor -= 1
            if self.round == 1 and self.blue_units[self.my_unit - 1].armor > 0:
                self.blue_units[self.my_unit - 1].armor -= 1
            self.new_round()

    def get_click(self, mouse_pos):
        cell = self.get_cell(mouse_pos)
        self.on_click(cell)
        self.update_info_who_beats()
        if not self.blue_can_beat:
            self.blue_can_beat = [0, 1, 2, 3]
        if not self.red_can_beat:
            self.red_can_beat = [0, 1, 2, 3]
        self.update_info_who_beats()

    def get_cell(self, mouse_pos):
        if 150 <= mouse_pos[0] <= 300 and 10 <= mouse_pos[1] <= 610:
            return 0, (mouse_pos[1] - 10) // 150
        elif 1050 <= mouse_pos[0] <= 1200 and 10 <= mouse_pos[1] <= 610:
            return 1, (mouse_pos[1] - 10) // 150

    def on_click(self, cell):
        if not cell:
            return
        if self.round == 0 and cell[0] == 0 and cell[1] in self.red_can_beat and self.red_units[cell[1]].cur_hp[
            0] > 0 or self.round == 1 and cell[
            0] == 1 and cell[1] in self.blue_can_beat and self.blue_units[cell[1]].cur_hp[0] > 0:
            self.my_unit = cell[1] + 1
        elif self.my_unit and self.round == 0 and cell[0] == 1 and self.blue_units[
            cell[1]].cur_hp[0] > 0 or self.my_unit and self.round == 1 and cell[0] == 0 and self.red_units[
            cell[1]].cur_hp[0] > 0:
            self.enemy_unit = cell[1] + 1

    def new_round(self):
        global red_sprites, blue_sprites, red_to_hide, blue_to_hide
        if self.round == 0:
            self.red_can_beat.remove(self.my_unit - 1)
            if not self.red_can_beat:
                self.red_can_beat = [0, 1, 2, 3]
                for i in range(4):
                    if self.red_units[i].cur_hp[0] <= 0:
                        self.red_can_beat.remove(i)
        else:
            self.blue_can_beat.remove(self.my_unit - 1)
            if not self.blue_can_beat:
                self.blue_can_beat = [0, 1, 2, 3]
                for i in range(4):
                    if self.blue_units[i].cur_hp[0] <= 0:
                        self.blue_can_beat.remove(i)
        self.enemy_unit = False
        self.my_unit = False
        self.round = (self.round + 1) % 2
        if not list(filter(lambda x: x.cur_hp[0] > 0, self.red_units)):
            a = len(list(filter(lambda x: x.cur_hp[0] > 0, self.blue_units)))
            finish('Второй', a)
        if not list(filter(lambda x: x.cur_hp[0] > 0, self.blue_units)):
            a = len(list(filter(lambda x: x.cur_hp[0] > 0, self.red_units)))
            finish('Первый', a)

    def update_info_who_beats(self):
        for i in range(4):
            if self.red_units[i].cur_hp[0] <= 0 and i in self.red_can_beat:
                self.red_can_beat.remove(i)
            if self.blue_units[i].cur_hp[0] <= 0 and i in self.blue_can_beat:
                self.blue_can_beat.remove(i)


class Unit:
    def __init__(self, damage, hp, img):
        self.damage = damage
        self.hp = hp
        self.cur_damage = [damage, 0]
        self.cur_hp = [hp, 0]
        self.s_attack = True
        self.img = img
        self.armor = 0
        self.counterattack = 0
        self.attack_xy = (3, 0)
        self.idle_xy = (3, 0)

    def hp(self):
        return self.hp

    def damage(self):
        return self.damage

    def img(self):
        return self.img

    def superattack(self):
        pass


class Golem(Unit):
    def __init__(self):
        super().__init__(1, 12, 'golem.png')
        self.attack_xy = (7, 0)
        self.idle_xy = (7, 0)
        self.death_xy = (7, 0)
        self.hurt_xy = (7, 0)
        self.super_xy = (7, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            if board.round == 0:
                board.red_golem = board.my_unit
            else:
                board.blue_golem = board.my_unit
            self.s_attack = False
        else:
            nr = False


class AcidMonstr(Unit):
    def __init__(self):
        super().__init__(4, 5, 'acid-monstr.png')
        self.attack_xy = (6, 0)
        self.idle_xy = (3, 0)
        self.death_xy = (7, 0)
        self.hurt_xy = (4, 0)
        self.super_xy = (8, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            for i in range(4):
                if board.round == 0:
                    board.red_units[i].cur_damage = [board.red_units[i].damage + 1, 1]
                else:
                    board.blue_units[i].cur_damage = [board.blue_units[i].damage + 1, 1]
            self.s_attack = False
        else:
            nr = False


class Alien(Unit):
    def __init__(self):
        super().__init__(3, 8, 'alien.png')
        self.attack_xy = (5, 0)
        self.idle_xy = (4, 0)
        self.death_xy = (11, 0)
        self.hurt_xy = (7, 0)
        self.super_xy = (11, 0)

    def superattack(self):
        global nr
        if self.s_attack and board.enemy_unit:
            if board.round == 0:
                board.blue_units[board.enemy_unit - 1].cur_damage = [0, 1]
                board.blue_units[board.enemy_unit - 1].cur_hp[0] -= 2
                if board.blue_units[board.enemy_unit - 1].cur_hp[0] > 0:
                    blue_sprites[board.enemy_unit - 1].change_status('hurt',
                                                                     *board.blue_units[board.enemy_unit - 1].hurt_xy)
                else:
                    blue_sprites[board.enemy_unit - 1].change_status('death',
                                                                     *board.blue_units[board.enemy_unit - 1].death_xy)

            else:
                board.red_units[board.enemy_unit - 1].cur_damage = [0, 1]
                board.red_units[board.enemy_unit - 1].cur_hp[0] -= 2
                if board.red_units[board.enemy_unit - 1].cur_hp[0] > 0:
                    red_sprites[board.enemy_unit - 1].change_status('hurt',
                                                                    *board.red_units[board.enemy_unit - 1].hurt_xy)
                else:
                    red_sprites[board.enemy_unit - 1].change_status('death',
                                                                    *board.red_units[board.enemy_unit - 1].death_xy)
            self.s_attack = False
        else:
            nr = False


class Maniak(Unit):
    def __init__(self):
        super().__init__(4, 6, "maniak.png")
        self.attack_xy = (4, 0)
        self.idle_xy = (3, 0)
        self.death_xy = (6, 0)
        self.hurt_xy = (3, 0)
        self.super_xy = (5, 0)

    def superattack(self):
        global nr
        if self.s_attack and board.enemy_unit:
            if board.round == 0:
                board.blue_units[board.enemy_unit - 1].cur_hp[0] -= 5
                if board.blue_units[board.enemy_unit - 1].cur_hp[0] > 0:
                    blue_sprites[board.enemy_unit - 1].change_status('hurt',
                                                                     *board.blue_units[board.enemy_unit - 1].hurt_xy)
                else:
                    blue_sprites[board.enemy_unit - 1].change_status('death',
                                                                     *board.blue_units[board.enemy_unit - 1].death_xy)
            else:
                board.red_units[board.enemy_unit - 1].cur_hp[0] -= 5
                if board.red_units[board.enemy_unit - 1].cur_hp[0] > 0:
                    red_sprites[board.enemy_unit - 1].change_status('hurt',
                                                                    *board.red_units[board.enemy_unit - 1].hurt_xy)
                else:
                    red_sprites[board.enemy_unit - 1].change_status('death',
                                                                    *board.red_units[board.enemy_unit - 1].death_xy)
            self.s_attack = False
        else:
            nr = False


class Ninja(Unit):
    def __init__(self):
        super().__init__(2, 7, "ninja.png")
        self.attack_xy = (7, 0)
        self.idle_xy = (6, 0)
        self.death_xy = (11, 0)
        self.hurt_xy = (3, 0)
        self.super_xy = (6, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            if board.round == 0:
                board.blue_golem = False
                for i in range(4):
                    board.blue_units[i].cur_hp[0] -= 1
                    board.blue_units[i].armor = 0
                    board.blue_units[i].counterattack = 0
                    board.blue_units[i].cur_hp[1] = 0
                    board.blue_units[i].cur_hp[0] = min(board.blue_units[i].cur_hp[0], board.blue_units[i].hp)
                    board.blue_units[i].cur_damage[0] = min(board.blue_units[i].cur_damage[0],
                                                            board.blue_units[i].damage)
                    if board.blue_units[i].cur_hp[0] > 0:
                        blue_sprites[i].change_status('hurt',
                                                      *board.blue_units[i].hurt_xy)
                    else:
                        blue_sprites[i].change_status('death',
                                                      *board.blue_units[i].death_xy)
            else:
                board.red_golem = False
                for i in range(4):
                    board.red_units[i].cur_hp[0] -= 1
                    board.red_units[i].armor = 0
                    board.red_units[i].counterattack = 0
                    board.red_units[i].cur_hp[1] = 0
                    board.red_units[i].cur_hp[0] = min(board.red_units[i].cur_hp[0], board.red_units[i].hp)
                    board.red_units[i].cur_damage[0] = min(board.red_units[i].cur_damage[0], board.red_units[i].damage)
                    if board.red_units[i].cur_hp[0] > 0:
                        red_sprites[i].change_status('hurt',
                                                     *board.red_units[i].hurt_xy)
                    else:
                        red_sprites[i].change_status('death',
                                                     *board.red_units[i].death_xy)
            self.s_attack = False
        else:
            nr = False


class OneHandKiller(Unit):
    def __init__(self):
        super().__init__(2, 10, "one-hand-killer.png")
        self.attack_xy = (10, 0)
        self.idle_xy = (3, 0)
        self.death_xy = (11, 0)
        self.hurt_xy = (4, 0)
        self.super_xy = (8, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            for i in range(4):
                if board.round == 0:
                    board.red_units[i].armor = 1
                else:
                    board.blue_units[i].armor = 1
            self.s_attack = False
        else:
            nr = False


class RoboCloud(Unit):
    def __init__(self):
        super().__init__(3, 6, "robo-cloud.png")
        self.attack_xy = (11, 0)
        self.idle_xy = (10, 0)
        self.death_xy = (7, 0)
        self.hurt_xy = (9, 0)
        self.super_xy = (12, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            for i in range(4):
                if board.round == 1:
                    board.red_units[i].cur_damage = [board.red_units[i].cur_damage[0] - 1, 1]
                else:
                    board.blue_units[i].cur_damage = [board.blue_units[i].cur_damage[0] - 1, 1]
            self.s_attack = False
        else:
            nr = False


class Robot(Unit):
    def __init__(self):
        super().__init__(2, 9, "robot.png")
        self.attack_xy = (7, 0)
        self.idle_xy = (11, 0)
        self.death_xy = (5, 0)
        self.hurt_xy = (7, 0)
        self.super_xy = (19, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            for i in range(4):
                if board.round == 1:
                    if board.blue_units[i].cur_hp[0] > 0:
                        board.blue_units[i].cur_hp[0] = min(board.blue_units[i].cur_hp[0] + 2,
                                                            board.blue_units[i].cur_hp[1] + board.blue_units[i].hp)
                else:
                    if board.red_units[i].cur_hp[0] > 0:
                        board.red_units[i].cur_hp[0] = min(board.red_units[i].cur_hp[0] + 2,
                                                           board.red_units[i].cur_hp[1] + board.red_units[i].hp)
            self.s_attack = False
        else:
            nr = False


class SeaMonstr(Unit):
    def __init__(self):
        super().__init__(2, 8, "sea-monstr.png")
        self.attack_xy = (3, 0)
        self.idle_xy = (4, 0)
        self.death_xy = (8, 0)
        self.hurt_xy = (3, 0)
        self.super_xy = (5, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            for i in range(4):
                if board.round == 1:
                    if board.blue_units[i].cur_hp[0] > 0:
                        board.blue_units[i].cur_hp[1] = 1
                        board.blue_units[i].cur_hp[0] += 1
                else:
                    if board.red_units[i].cur_hp[0] > 0:
                        board.red_units[i].cur_hp[1] = 1
                        board.red_units[i].cur_hp[0] += 1

            self.s_attack = False
        else:
            nr = False


class Superghost(Unit):
    def __init__(self):
        super().__init__(3, 6, "superghost.png")
        self.attack_xy = (6, 0)
        self.idle_xy = (4, 0)
        self.death_xy = (4, 0)
        self.hurt_xy = (2, 0)
        self.super_xy = (9, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            for i in range(4):
                if board.round == 0:
                    board.blue_units[i].cur_hp[0] -= 2
                    if board.blue_units[i].cur_hp[0] > 0:
                        blue_sprites[i].change_status('hurt',
                                                      *board.blue_units[i].hurt_xy)
                    else:
                        blue_sprites[i].change_status('death',
                                                      *board.blue_units[i].death_xy)
                else:
                    board.red_units[i].cur_hp[0] -= 2
                    if board.red_units[i].cur_hp[0] > 0:
                        red_sprites[i].change_status('hurt',
                                                     *board.red_units[i].hurt_xy)
                    else:
                        red_sprites[i].change_status('death',
                                                     *board.red_units[i].death_xy)
            self.s_attack = False
        else:
            nr = False


class Witch(Unit):
    def __init__(self):
        super().__init__(3, 6, "magician.png")
        self.attack_xy = (5, 0)
        self.idle_xy = (12, 0)
        self.death_xy = (9, 0)
        self.hurt_xy = (3, 0)
        self.super_xy = (4, 0)

    def superattack(self):
        global nr
        if self.s_attack:
            for i in range(4):
                if board.round == 0:
                    board.red_units[i].counterattack = 2
                else:
                    board.blue_units[i].counterattack = 2
            self.s_attack = False
        else:
            nr = False


def saclean():
    global nr
    if board.round == 0:
        if board.red_units[board.my_unit - 1].s_attack and board.red_units[
            board.my_unit - 1].cur_damage == [0, 1]:
            board.red_units[board.my_unit - 1].s_attack = False
        board.red_units[board.my_unit - 1].armor = max(0, board.red_units[board.my_unit - 1].armor - 1)
        board.red_units[board.my_unit - 1].counterattack = max(0, board.red_units[board.my_unit - 1].counterattack - 1)
        board.red_units[board.my_unit - 1].cur_damage[1] = max(0, board.red_units[board.my_unit - 1].cur_damage[1] - 1)
        if board.red_units[board.my_unit - 1].cur_damage == [0, 0]:
            board.red_units[board.my_unit - 1].cur_damage = [board.red_units[board.my_unit - 1].damage, 0]
            board.new_round()
            nr = False
    else:
        if board.blue_units[board.my_unit - 1].s_attack and board.blue_units[
            board.my_unit - 1].cur_damage == [0, 1]:
            board.blue_units[board.my_unit - 1].s_attack = False
        board.blue_units[board.my_unit - 1].armor = max(0, board.blue_units[board.my_unit - 1].armor - 1)
        board.blue_units[board.my_unit - 1].counterattack = max(0,
                                                                board.blue_units[board.my_unit - 1].counterattack - 1)
        board.blue_units[board.my_unit - 1].cur_damage[1] = max(0,
                                                                board.blue_units[board.my_unit - 1].cur_damage[1] - 1)
        if board.blue_units[board.my_unit - 1].cur_damage == [0, 0]:
            board.blue_units[board.my_unit - 1].cur_damage = [board.blue_units[board.my_unit - 1].damage, 0]
            board.new_round()
            nr = False


class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, clas, columns, y, idle_column, idle_y, pos_x, pos_y, status='idle'):
        super().__init__(all_sprites)
        self.status = status
        self.frames = []
        self.idle_column = idle_column
        self.idle_y = idle_y
        self.clas = clas
        self.pos = (pos_x, pos_y)
        self.cut_sheet(load_image(f'data/{clas}_{status}.png'), columns, y)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = self.rect.move(0, y)

    def cut_sheet(self, sheet, columns, y):
        self.rect = pygame.Rect(*self.pos, (sheet.get_width() - y) // columns,
                                sheet.get_height())
        for j in range(columns):
            frame_location = (self.rect.w * j, 0)
            self.frames.append(sheet.subsurface(pygame.Rect(
                frame_location, self.rect.size)))

    def change_status(self, new, column, y):
        self.status = new
        self.frames = []
        self.cut_sheet(load_image(f'data/{self.clas}_{new}.png'), column, y)

    def update(self):
        if self.status != 'idle' and self.cur_frame + 1 == len(self.frames):
            self.change_status('idle', self.idle_column, self.idle_y)
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]


clock = pygame.time.Clock()
board = Board()
pygame.init()
nr = False


def battle(red_un, blue_un):
    global all_sprites, board, nr, red_sprites, blue_sprites, red_to_hide, blue_to_hide
    pygame.display.set_caption('Бой')
    size = width, height = 1350, 690
    screen = pygame.display.set_mode(size)
    all_sprites = pygame.sprite.Group()
    screen.fill(pygame.Color('grey'))

    names = ['acid-monstr', 'alien', 'golem', 'maniak', 'ninja', 'one-hand-killer', 'robo-cloud', 'robot',
             'sea-monstr', 'superghost', 'witch']
    classes = [AcidMonstr(), Alien(), Golem(), Maniak(), Ninja(), OneHandKiller(), RoboCloud(), Robot(), SeaMonstr(),
               Superghost(), Witch()]
    board.red_units = [0, 0, 0, 0]
    board.blue_units = [0, 0, 0, 0]
    for i in range(4):
        board.red_units[i] = classes[names.index(red_un[i])]
        board.blue_units[i] = classes[names.index(blue_un[i])]

    board.sprites(screen1)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                board.get_click(event.pos)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                board.attack()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                if board.my_unit:
                    nr = True
                    saclean()
                    if board.round == 0 and board.my_unit:
                        board.red_units[board.my_unit - 1].superattack()
                        red_sprites[board.my_unit - 1].change_status('super',
                                                                     *board.red_units[board.my_unit - 1].super_xy)
                    elif board.my_unit:
                        board.blue_units[board.my_unit - 1].superattack()
                        blue_sprites[board.my_unit - 1].change_status('super',
                                                                      *board.blue_units[board.my_unit - 1].super_xy)
                    if nr:
                        board.new_round()
        screen1.fill(pygame.Color('grey'))
        board.render(screen1)
        all_sprites.update()
        all_sprites.draw(screen1)
        clock.tick(4)
        board.print_info(screen1)
        board.no_info_about_dead(screen1)
        pygame.display.flip()
    pygame.quit()


start_screen()
